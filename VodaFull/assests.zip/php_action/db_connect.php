<?php 	

$localhost = "127.0.0.1";
$username = "thevoda1_adm";
$password = "adm123@@";
$dbname = "thevoda1_stock";

// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>